# #' @export
#
# print.threshold_detection <- function(x, ...)
# {
#   print(x$event_data)
# }
#
# #' @export
#
# print.blob_detection <- function(x, ...)
# {
#   print(x$event_data)
# }
