#' @import yaml
#' @export 
print.fs_object <- function(x, ...){
#  cat(as.yaml(x))
x
}

#' @import yaml
#' @export 
summary.fs_object <- function(object, ...){
#  cat(as.yaml(object))
  object
}


