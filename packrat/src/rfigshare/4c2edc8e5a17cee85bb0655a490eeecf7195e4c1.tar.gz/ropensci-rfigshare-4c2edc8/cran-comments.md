Dear CRAN maintainers,

This release fixes the title format and should address a compatibility issue with the httr package dependency prior to the release of httr 1.0.
I have now also addressed the issues in DESCRIPTION file, my apologies for not addressing these in the original update.

Sincerely,

Carl Boettiger
